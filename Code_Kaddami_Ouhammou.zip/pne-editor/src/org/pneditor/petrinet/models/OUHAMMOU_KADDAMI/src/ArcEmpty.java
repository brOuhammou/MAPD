package org.pneditor.petrinet.models.OUHAMMOU_KADDAMI.src;

import org.pneditor.petrinet.models.OUHAMMOU_KADDAMI.Exceptions.NbtokenException;

public class ArcEmpty extends ArcIn {

	public ArcEmpty(int weight, Place place) throws NbtokenException {
		super(weight, place);	
	}
	// Enable permet d'activer l'arc empty 
	public void Enable() {
		place.empty();
	}
	// isEnabled permet de vérifier si l'arc empty peut être activé (la place doit être non vide)
	public boolean isEnabled(){
		return place.NotEmpty();
	}
	

}
