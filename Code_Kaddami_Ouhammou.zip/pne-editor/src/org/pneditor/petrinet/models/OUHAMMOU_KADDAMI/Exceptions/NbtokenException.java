package org.pneditor.petrinet.models.OUHAMMOU_KADDAMI.Exceptions;

public class NbtokenException extends Exception {
	public NbtokenException(String message) {
		super(message);
		//Exception lorsque le nb_token d'une place ou le poids d'un arc est négatif
	}

}
