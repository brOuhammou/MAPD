package org.pneditor.petrinet.models.OUHAMMOU_KADDAMI.src;

import org.pneditor.petrinet.models.OUHAMMOU_KADDAMI.Exceptions.NbtokenException;

public class ArcZero extends ArcIn {

	public ArcZero(int weight, Place place) throws NbtokenException {
		super(weight, place);
	}
	// redéfintion de isEnabled: permet de vérifier si l'arc zero peut être activé (la place doit être vide) 
	public boolean isEnabled() {
		return place.isEmpty();
	}
	//redéfinition de la méthode isFirable de la classe parente: retourne toujours true.
	public boolean isFirable() {
		return true;
	}
	// redéfinition de Enable: vide la place à laquelle l'arc est lié de ses jetons.
	public void Enable() {
		place.empty();
	}
	

}
