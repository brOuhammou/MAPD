package org.pneditor.petrinet.models.OUHAMMOU_KADDAMI.src;

import java.util.LinkedList;

import org.pneditor.petrinet.models.OUHAMMOU_KADDAMI.Exceptions.NbtokenException;
import org.pneditor.petrinet.models.OUHAMMOU_KADDAMI.Exceptions.doublearcException;

public class PetriNet implements IPetriNet {
	private LinkedList<Place> places;
	private LinkedList<Transition> transitions;
	private LinkedList<ArcIn> List_ArcsIn;
	private LinkedList<ArcOut> List_ArcsOut;
	public PetriNet() {
		places = new LinkedList<Place>();
		transitions = new LinkedList<Transition>();
		List_ArcsIn = new LinkedList<ArcIn>();
		List_ArcsOut = new LinkedList<ArcOut>();
	}
	
	// les fonctions get sont utilisées pour les tests et l'affichage.
	public LinkedList<Place> get_places(){
		return this.places;
	}
	@Override
	public LinkedList<ArcIn> get_ArcsIn() {
		return this.List_ArcsIn;		
	}

	@Override
	public LinkedList<ArcOut> get_ArcsOut() {
		return this.List_ArcsOut;
		
	}

	@Override
	public LinkedList<Transition> get_transitions() {
		return this.transitions;
		
	}
	// tirer_transition qui permet de tirer une transition en vérifiant avant si elle est tirable.
	public void  tirer_transition(Transition transition) {
		if (transition.isFirable()) {
			transition.Fire();
		}
	}
	@Override
	// add_arcIn permet d'ajouter arcin dans la liste List_ArcsIn et dans la liste ArcIn de transition avec laquelle cette arc est lié
	public void add_arcIn(int weight, Place place, Transition transition) throws NbtokenException, doublearcException {
		boolean verife = true;
		for (ArcIn arcin: transition.getArcIn()) {
			if(arcin.get_place()==place) {
				verife=false;
			}
		}
		if (verife==false) {
			throw new doublearcException("impossible de créer des arcs doubles entrants");
		}
		else {
			ArcIn arcIn= new ArcIn(weight,place);
			List_ArcsIn.add(arcIn);
			transition.addarcIn(weight, place,arcIn);
		}
		
		
	}
	@Override
	//add_arcOut permet d'ajouter arcout dans la liste List_ArcsOut et dans la liste ArcOut de transition avec laquelle cette arc est lié 
	public void add_arcOut(int weight, Place place, Transition transition) throws NbtokenException {
		ArcOut arcOut= new ArcOut(weight,place);
		List_ArcsOut.add(arcOut);
		transition.addarcOut(weight, place, arcOut);
	}
	@Override
	// add_arcEmpty permet d'ajouter arcepmty dans la liste List_ArcsIn et dans la liste ArcIn de transition avec laquelle cette arc est lié
	public void add_arcEmpty(int weight, Place place, Transition transition) throws NbtokenException {
		ArcEmpty arcempty = new ArcEmpty(weight,place);
		List_ArcsIn.add(arcempty);
        transition.addarcIn(weight, place,arcempty);
	}
	@Override
	// add_arcZero permet d'ajouter arczero dans la liste List_ArcsIn et dans la liste ArcIn de transition avec laquelle cette arc est lié
	public void add_arcZero(int weight, Place place, Transition transition)throws NbtokenException {
		ArcZero arczero = new ArcZero(weight,place);
		List_ArcsIn.add(arczero);
        transition.addarcIn(weight, place,arczero);
	}
	@Override
	// add_transition permet d'ajouter transition dans la liste transitions 
	public void add_transition() {
		transitions.add(new Transition());
		
	}
	@Override
	// add_place permet d'ajouter place dans la liste places
	public void add_place(int nb_token)throws NbtokenException {
		places.add(new Place(nb_token));
		
	}
	@Override
	// remove_arcIn permet de supprimer arcIn dans la liste List_ArcsIn et dans la liste ArcIn de transition avec laquelle cette arc est lié
	public void remove_arcIn(ArcIn arcIn) {
		List_ArcsIn.remove(arcIn);
		for(Transition transition: transitions) {
			for (ArcIn arcin:transition.getArcIn() ) {
				if (arcin == arcIn) {
					transition.removearcIn(arcIn) ;
				}
			}
		}
	}
	@Override
	//remove_arcOut permet de supprimer arcout dans la liste List_ArcsOut et dans la liste ArcOut de transition avec laquelle cette arc est lié
	public void remove_arcOut(ArcOut arcOut) {
		List_ArcsOut.remove(arcOut);
		for(Transition transition: transitions) {
			for (ArcOut arcout:transition.getArcOut() ) {
				if (arcout == arcOut) {
					transition.removearcOut(arcOut) ;
				}
			}
		}
		
	}
	@Override
	// remove_transition permet de supprimer transition et tous les arcsin et arcsout qui sont liés à cette transition  
	public void remove_transition(Transition transition) {
		transitions.remove(transition);
		for (ArcIn arcin:transition.getArcIn() ) {
			List_ArcsIn.remove(arcin) ;
		}
		for (ArcOut arcout:transition.getArcOut() ) {
			List_ArcsOut.remove(arcout) ;
		}
		
	}
	@Override
	// remove_place permet de supprimer place et tous les arcsin et arcsout qui sont liés à cette place
	public void remove_place(Place place) {
	   places.remove(place);
	   for (ArcIn arcin: List_ArcsIn ) {
		   if(arcin.get_place()==place) {
			   remove_arcIn(arcin);
		   }
	    for (ArcOut arcout: List_ArcsOut ) {
			   if(arcout.get_place()==place) {
				   remove_arcOut(arcout);
			   }
	    }
	   }
		
	}
	@Override
	// add_token permet d'ajouter un nombre au nb_token d'une place
	public void add_token(int nb_token, Place place) {
		place.add_token(nb_token);
		
	}
	@Override
	// remove_token permet de supprimer un nombre de nb_token d'une place
	public void remove_token(int nb_token, Place place) {
		place.remove_token(nb_token);
		
	}
	@Override
	// change_weight_ArcIn pemret de changer le weight d'un arcin
	public void change_weight_ArcIn(int weight, ArcIn arcIn) {
		arcIn.setweight(weight);
		
	}
	@Override
	// change_weight_ArcOut pemret de changer le weight d'un arcout
	public void change_weight_ArcOut(int weight, ArcOut arcOut) {
		arcOut.setweight(weight);
	}

	
	// toString permet d'afficher le contenu de PetriNet
	
	public String toString() {
		int arcsize = this.List_ArcsIn.size()+ this.List_ArcsOut.size();
		String res = "Petri Network \n" + "   "+ this.places.size() + " places \n" + "   "+ this.transitions.size() + " transitions \n" + "   " + arcsize + " arcs \n" + "Liste Place :  \n" ;
		int i=0;
		for(Place p : this.places) {
	    	i=i+1;
	    	int nbEnteringArc = 0;
		    int nbExitingArc = 0;
			for (ArcIn arcin : this.List_ArcsIn ) {
				if (arcin.get_place() == p) {
						nbEnteringArc++;
					}}
			for (ArcOut arcout : this.List_ArcsOut ) {	
				if (arcout.get_place() == p) {
						nbExitingArc++;
					}
				}
	    	res =res + "   " + i+ ": place avec " + p.getToken() + "jetons, " + nbExitingArc+ "arc entrant, " + nbEnteringArc +" arc sortant \n"  ;
	    }
	    res = res + "Liste des Transitions :  \n";
		for(Transition t : this.transitions) {
			res = res + "   transition, " + (t.getArcIn()).size() + "arc entrant, " + (t.getArcOut()).size() + "arc sortant \n";
		}
		res = res + "Liste des Arcs :  \n";
		for(ArcIn a : this.List_ArcsIn) {
			res = res + "   Arc poids " + a.get_weight() + " (place avec " + a.get_place().getToken() + " jetons vers Transition ) \n";
		}
		for(ArcOut a : this.List_ArcsOut) {
			res = res + "   Arc poids " + a.get_weight() + " (Transition  vers  place avec " + a.get_place().getToken() +" jetons) \n";
		}
		System.out.println(res);
		return res;
	
	}

	



	

}
