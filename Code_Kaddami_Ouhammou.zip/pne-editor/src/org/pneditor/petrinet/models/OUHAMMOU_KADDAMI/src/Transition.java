package org.pneditor.petrinet.models.OUHAMMOU_KADDAMI.src;
import java.util.LinkedList;

public class Transition {
	private LinkedList<ArcIn> ArcIn;
	private LinkedList<ArcOut> ArcOut;
	public Transition() {
		ArcIn= new LinkedList<ArcIn>();
		ArcOut= new LinkedList<ArcOut>();
	}
	// Fire permet de tirer une transition
	public void Fire() {
		for (ArcIn arcin: ArcIn) {
		   if (arcin.isEnabled()) {
			   arcin.Enable();
		   }
		}
		for (ArcOut arcout: ArcOut) {
				   arcout.Enable();
			   }
		
	}
	// isFirable permet de savoir si une transtion est tirable ou non
	public boolean isFirable() {
		boolean bl= true;
		for (ArcIn arcin: ArcIn) {
			if(arcin.isFirable()==false) {
				bl=false;
			}
		}
		return bl;
	}
	// addarcOut permet d'ajouter un arcout à la liste ArcOut
	public void addarcOut(int weight,Place place, ArcOut arcout) {
		ArcOut.add(arcout);
	}
	// addarcIn permet d'ajouter un arcin à la liste ArcIn
	public void addarcIn(int weight,Place place, ArcIn arcin) {
		ArcIn.add(arcin);
	}
	// removearcIn permet de supprimer un arcin de ArcIn
	public void removearcIn(ArcIn arcin) {
		ArcIn.remove(arcin);
	}
	// removearcOut permet de supprimer un arcout de ArcOut
	public void removearcOut(ArcOut arcout) {
		ArcOut.remove(arcout);
	}
	
	//les méthodes get sont utilisées pour les tests et l'affichage
	public LinkedList<ArcOut> getArcOut(){
		return ArcOut;
	}
	public LinkedList<ArcIn> getArcIn(){
		return ArcIn;
	}
	
}
