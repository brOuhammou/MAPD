package org.pneditor.petrinet.models.OUHAMMOU_KADDAMI.src;

import org.pneditor.petrinet.models.OUHAMMOU_KADDAMI.Exceptions.NbtokenException;

public class Place {
	private int nb_token;
	
	//constructeur renvoie une exception si le nombre de token est négatif.
	public Place(int nb_token) throws NbtokenException {
		if(nb_token<0) {
		throw new NbtokenException("le nb_token doit etre positif");
		}
		else {
			this.nb_token=nb_token;
		}
	}
	
	// Les Méthodes get sont utilisées seulement pour les tests et l'affichage
	public int getToken() {
		return this.nb_token;
	}
	// isEmpty permet de vérifier si le nb_token est null ou non (utilisée pour les arcs zéro)
	public boolean isEmpty() {
		if (this.nb_token==0) {
			return true;
		}
		else {
			return false;
		}
	}
	// NotEmpty elle fait l'inverse de isEmpty (utilisée pour les arc empty)
	public boolean NotEmpty() {
		if (this.nb_token==0) {
			return false;
		}
		else {
			return true;
	}
	}
	// isEnough permet de vérfier si le nb_token est plus grand que le poids 
	public boolean isEnough(int weight) {
		return weight <=nb_token;
		
	}
	// empty elle rend la place empty(nb_token=0)
	public void empty() {
		nb_token=0;
	}
	// add_token permet d'ajouter un nombre au nb_token d'une place
	public void add_token(int nb) {
		nb_token=nb_token+Math.abs(nb);
	}
	// remove_token permet de supprimer un nombre de nb_token d'une place
	public void remove_token(int nb) {
		if (nb_token > nb) {
			nb_token= nb_token-nb;
		}
		else {
			nb_token=0;
		}
	}

	
		
	}


