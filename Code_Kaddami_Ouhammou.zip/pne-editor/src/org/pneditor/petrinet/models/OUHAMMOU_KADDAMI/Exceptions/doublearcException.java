package org.pneditor.petrinet.models.OUHAMMOU_KADDAMI.Exceptions;

public class doublearcException extends Exception {
	public doublearcException(String message) {
		super(message);
		
	}
}
