package org.pneditor.petrinet.models.OUHAMMOU_KADDAMI.src;

import java.util.LinkedList;

import org.pneditor.petrinet.models.OUHAMMOU_KADDAMI.Exceptions.NbtokenException;
import org.pneditor.petrinet.models.OUHAMMOU_KADDAMI.Exceptions.doublearcException;

public interface IPetriNet {
	public LinkedList<Place> get_places();
	public LinkedList<ArcIn> get_ArcsIn();
	public LinkedList<ArcOut> get_ArcsOut();
	public LinkedList<Transition> get_transitions();
	public void  tirer_transition(Transition transition);
	public void add_arcIn(int weight,Place place, Transition transition) throws NbtokenException, doublearcException;
	public void add_arcOut(int weight,Place place, Transition transition)  throws NbtokenException;
	public void add_arcEmpty(int weight,Place place, Transition transition)throws NbtokenException;
	public void add_arcZero(int weight,Place place, Transition transition)throws NbtokenException;
	public void add_transition();
	public void add_place (int nb_token) throws NbtokenException;
	public void remove_arcIn(ArcIn arcIn);
	public void remove_arcOut(ArcOut arcOut);
	public void remove_transition(Transition transition);
	public void remove_place(Place place);
	public void add_token(int nb_token, Place place);
	public void remove_token(int nb_token, Place place);
	public void change_weight_ArcIn(int weight, ArcIn arcIn);
	public void change_weight_ArcOut(int weight, ArcOut arcOut);
	public String toString();
}
