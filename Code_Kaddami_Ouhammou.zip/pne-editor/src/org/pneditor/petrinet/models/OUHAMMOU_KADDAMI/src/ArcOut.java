package org.pneditor.petrinet.models.OUHAMMOU_KADDAMI.src;

import org.pneditor.petrinet.models.OUHAMMOU_KADDAMI.Exceptions.NbtokenException;

public class ArcOut {
	private int weight;
	private Place place;
	
	//constructeur de l'arcOut
	//renvoie une exception si le poids est inférieur à 0
	public ArcOut(int weight,Place place) throws NbtokenException {
		if(weight<0) {
		throw new NbtokenException("le poids doit etre positif");
		}
		else {
			this.weight=weight;
			this.place=place;
		}}
	public Place get_place() {
		return this.place;
	}
	public int get_weight() {
		return this.weight;
	}
	// setweight permet de modifier le weight d'un arc
	public void setweight(int n) {
		this.weight=n;
	}
	// Enable permet de rendre un arc actif
	public void Enable() {
		place.add_token(weight);
	}
}
