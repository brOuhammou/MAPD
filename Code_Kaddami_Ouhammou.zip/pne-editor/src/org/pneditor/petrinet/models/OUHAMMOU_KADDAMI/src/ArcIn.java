package org.pneditor.petrinet.models.OUHAMMOU_KADDAMI.src;

import org.pneditor.petrinet.models.OUHAMMOU_KADDAMI.Exceptions.NbtokenException;

public class ArcIn {
	protected  int weight;
	protected Place place;
	
	//Le constructeur de l'arc
	// renvoie une exception si le poids mis est inférieur à 0
	public ArcIn(int weight,Place place) throws NbtokenException {
		if(weight<0) {
		throw new NbtokenException("le poids doit etre positif");
		}
		else {
			this.weight=weight;
			this.place=place;
		}
	} 
	
	// les méthodes get sont utilisés seulement dans les tests et la fonction toString de PetriNet.
	public Place get_place() {
		return this.place;
	}
	public int get_weight() {
		return this.weight;
	}
	// isEnabled permet de vérifier si l'arc In peut être activé 
	public boolean isEnabled() {
		return true;
	}
	//permet de vérfier si le nb_token de la place auquel l'arc est lié est plus grand que son poids (ie si l'arc est tirable)
	public boolean isFirable() {
		return place.isEnough(weight);
	}
	// setweight permet de modifier le poids de l'arc
	public void setweight(int n) {
		this.weight=n;
	}
	// Enable permet de rendre d'activer l'arc entrant
    public void Enable() {
    	place.remove_token(weight);
    }
    
}
