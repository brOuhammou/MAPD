package org.pneditor.petrinet.adapters.OUHAMMOU_KADDAMI;

import org.pneditor.petrinet.AbstractPlace;
import org.pneditor.petrinet.models.OUHAMMOU_KADDAMI.Exceptions.NbtokenException;
import org.pneditor.petrinet.models.OUHAMMOU_KADDAMI.src.Place;

public class PlaceAdapter extends AbstractPlace {
	private Place place;
	public PlaceAdapter(String label) throws NbtokenException  {
		super(label);
		place = new Place(0);
	}
	
	/**
	 * @return Place
	 */
	public Place getPlace() {
		return this.place;
	}
 
	/**
	 * La methode addToken() permet d'ajouter un jeton au nombre de jetons de la place
	 */
	@Override
	public void addToken() {
		place.add_token(1);
		
	}

	/**
	 * La methode removeToken() permet de supprimer un jeton au nombre de jetons de la place 
	 */
	@Override
	public void removeToken() {
		place.remove_token(1);
		
	}
	/**
	 * @return nb_token
	 */
	@Override
	public int getTokens() {
		return place.getToken();
	}

	/**
	 * La methode setTokens permet de changer le nombre de jetons de la place
	 */
	@Override
	public void setTokens(int tokens) {
		place.remove_token(place.getToken());
		place.add_token(tokens);	
		
	}

}
