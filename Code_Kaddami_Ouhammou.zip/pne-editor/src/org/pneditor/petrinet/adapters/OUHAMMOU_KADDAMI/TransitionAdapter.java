package org.pneditor.petrinet.adapters.OUHAMMOU_KADDAMI;

import org.pneditor.petrinet.AbstractTransition;
import org.pneditor.petrinet.models.OUHAMMOU_KADDAMI.src.Transition;

public class TransitionAdapter extends AbstractTransition {
	
      Transition transition;
	  public TransitionAdapter(String label) {
		 super(label);
		 transition = new Transition();
	 }
	  public Transition getTransition() {
	 	return transition;
	 }
	  
	
	
	

}
