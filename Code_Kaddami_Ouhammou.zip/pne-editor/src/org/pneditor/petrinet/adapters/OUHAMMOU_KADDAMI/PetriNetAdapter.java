package org.pneditor.petrinet.adapters.OUHAMMOU_KADDAMI;

import org.pneditor.petrinet.AbstractArc;
import org.pneditor.petrinet.AbstractNode;
import org.pneditor.petrinet.AbstractPlace;
import org.pneditor.petrinet.AbstractTransition;
import org.pneditor.petrinet.PetriNetInterface;
import org.pneditor.petrinet.ResetArcMultiplicityException;
import org.pneditor.petrinet.UnimplementedCaseException;
import org.pneditor.petrinet.models.OUHAMMOU_KADDAMI.Exceptions.NbtokenException;
import org.pneditor.petrinet.models.OUHAMMOU_KADDAMI.Exceptions.doublearcException;
import org.pneditor.petrinet.models.OUHAMMOU_KADDAMI.src.ArcEmpty;
import org.pneditor.petrinet.models.OUHAMMOU_KADDAMI.src.ArcIn;
import org.pneditor.petrinet.models.OUHAMMOU_KADDAMI.src.ArcOut;
import org.pneditor.petrinet.models.OUHAMMOU_KADDAMI.src.ArcZero;
import org.pneditor.petrinet.models.OUHAMMOU_KADDAMI.src.PetriNet;
import org.pneditor.petrinet.models.OUHAMMOU_KADDAMI.src.Place;
import org.pneditor.petrinet.models.OUHAMMOU_KADDAMI.src.Transition;

/**
 * @author BRAHIM
 *
 */
public class PetriNetAdapter extends PetriNetInterface {
	private PetriNet petrinet;
	public PetriNetAdapter() {
		this.petrinet= new PetriNet();
	}
	
	/**
	 * La methode addPlace permet d'ajouter une place dans le reseau PetriNet
	 */
	@Override
	public AbstractPlace addPlace() {
		PlaceAdapter place;
		try {
			place= new PlaceAdapter("place");
			petrinet.add_place(place.getPlace().getToken());
			return place;
		}
		catch (NbtokenException e) {
			e.getStackTrace();
		}
		return null;
	}

	/**
	 * La methode addPlace permet d'ajouter une transition dans le reseau PetriNet
	 */
	@Override
	public AbstractTransition addTransition() {
		TransitionAdapter transition = new TransitionAdapter("transition");
		petrinet.add_transition();
		return transition;
	}

	/**
	 * La methode addPlace permet d'ajouter un arc dans le reseau PetriNet
	 */
	@Override
	public AbstractArc addRegularArc(AbstractNode source, AbstractNode destination) throws UnimplementedCaseException {
		PlaceAdapter p;
		TransitionAdapter t;
		if (source instanceof AbstractPlace && destination instanceof AbstractTransition ) {
			p= (PlaceAdapter) source;
			t= (TransitionAdapter) destination;
			try {
				petrinet.add_arcIn(1,p.getPlace(),t.getTransition());
				ArcIn a = petrinet.get_ArcsIn().getLast();
				ArcAdapter arc = new ArcAdapter(t,p,a,null);
				return arc;
			}
			catch (doublearcException | NbtokenException e) {
				e.printStackTrace();
			}	
		}
		else {
			p= (PlaceAdapter) destination;
			t= (TransitionAdapter) source;
			try {
				petrinet.add_arcOut(1,p.getPlace(),t.getTransition());
				ArcOut a = petrinet.get_ArcsOut().getLast();
				ArcAdapter arc = new ArcAdapter(t,p,null,a);
				return arc;
			}
			catch (NbtokenException e) {
				e.printStackTrace();
			}
		}
		return null;
	}

	/**
	 * La methode addPlace permet d'ajouter un arcZero dans le reseau PetriNet
	 */
	@Override
	public AbstractArc addInhibitoryArc(AbstractPlace place, AbstractTransition transition)
			throws UnimplementedCaseException {
		PlaceAdapter p= (PlaceAdapter) place;
		TransitionAdapter t= (TransitionAdapter) transition;
		try {
			petrinet.add_arcZero(1,p.getPlace(),t.getTransition());
			ArcIn a = petrinet.get_ArcsIn().getLast();
			ArcAdapter arc = new ArcAdapter(t,p,a,null);
			return arc;
		}
		catch (NbtokenException e) {
			e.printStackTrace();
		}
		return null;
	}
	

	/**
	 * La methode addPlace permet d'ajouter un arc vide dans le reseau PetriNet
	 */
	@Override
	public AbstractArc addResetArc(AbstractPlace place, AbstractTransition transition)
			throws UnimplementedCaseException {
		PlaceAdapter p= (PlaceAdapter) place;
		TransitionAdapter t= (TransitionAdapter) transition;
		try {
			petrinet.add_arcEmpty(1,p.getPlace(),t.getTransition());
			ArcIn a = petrinet.get_ArcsIn().getLast();
			ArcAdapter arc = new ArcAdapter(t,p,a,null);
			return arc;
		}
		catch (NbtokenException e) {
			e.printStackTrace();
		}
		return null;
	}

	/**
	 * La methode removePlace permet de supprimer une place de reseau PetriNet
	 */
	@Override
	public void removePlace(AbstractPlace place) {
		Place p = ((PlaceAdapter) place).getPlace();
		petrinet.remove_place(p);
	}
   
	/**
	 * La methode removePlace permet de supprimer une transition de reseau PetriNet
	 */
	@Override
	public void removeTransition(AbstractTransition transition) {
		Transition t = ((TransitionAdapter) transition).getTransition();
		petrinet.remove_transition(t);
		
	}
	/**
	 * La methode removeArc permet de supprimer un arc de reseau PetriNet
	 */
	@Override
	public void removeArc(AbstractArc arc) {
		ArcIn arcin = ((ArcAdapter) arc).getArcIn();
		ArcOut arcout = ((ArcAdapter) arc).getArcOut();
		if (arcin == null) {
			petrinet.remove_arcOut(arcout);
		}
		else {
			petrinet.remove_arcIn(arcin);
		}
	}

	/**
	 * La methode isEnabled permet verifier si une transition est tirable
	 */
	@Override
	public boolean isEnabled(AbstractTransition transition) throws ResetArcMultiplicityException {
		Transition t = ((TransitionAdapter) transition).getTransition();
		System.out.println(((petrinet.get_ArcsIn()).get(0)).get_weight());
		return t.isFirable();
	}

	/**
	 * La methode fire permet de tirer une transition
	 */
	@Override
	public void fire(AbstractTransition transition) throws ResetArcMultiplicityException {
		Transition t = ((TransitionAdapter) transition).getTransition();
		
		//System.out.println(transition.isFirable());
	     petrinet.tirer_transition(t);
	}

}
