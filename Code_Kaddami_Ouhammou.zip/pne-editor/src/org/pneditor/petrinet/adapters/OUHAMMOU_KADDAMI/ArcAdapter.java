package org.pneditor.petrinet.adapters.OUHAMMOU_KADDAMI;

import org.pneditor.petrinet.AbstractArc;
import org.pneditor.petrinet.AbstractNode;
import org.pneditor.petrinet.AbstractPlace;
import org.pneditor.petrinet.AbstractTransition;
import org.pneditor.petrinet.ResetArcMultiplicityException;
import org.pneditor.petrinet.models.OUHAMMOU_KADDAMI.Exceptions.NbtokenException;
import org.pneditor.petrinet.models.OUHAMMOU_KADDAMI.src.ArcEmpty;
import org.pneditor.petrinet.models.OUHAMMOU_KADDAMI.src.ArcIn;
import org.pneditor.petrinet.models.OUHAMMOU_KADDAMI.src.ArcOut;
import org.pneditor.petrinet.models.OUHAMMOU_KADDAMI.src.ArcZero;
import org.pneditor.petrinet.models.OUHAMMOU_KADDAMI.src.PetriNet;
import org.pneditor.petrinet.models.OUHAMMOU_KADDAMI.src.Transition;

public class ArcAdapter extends AbstractArc {
	PetriNet pn;
	ArcIn arcin;
	ArcOut arcout;
	AbstractTransition t ;
	PlaceAdapter p;
	
	public ArcAdapter(AbstractTransition t,PlaceAdapter p, ArcIn arcin ,ArcOut arcout) throws NbtokenException {
		this.t=t;
		this.p=p;
		this.arcin=arcin;
		this.arcout=arcout;
	}
	/**
	 * @return ArcIn
	 */
	public ArcIn getArcIn() {
		return this.arcin;
	}
	/**
	 * @return ArcOut
	 */
	public ArcOut getArcOut() {
		return this.arcout;
	}
	
	/**
	 * La methode getSource permet de retourner le source de l'arc
	 */
	@Override
	public AbstractNode getSource() {
		if (arcin==null) {
			 return t;
		}
		else {
			return p;
		}
	}

	/**
	 * La methode getDestination permet de retourner la destination de l'arc
	 */
	@Override
	public AbstractNode getDestination() {
		if (arcin==null) {
			 return p;
		}
		else {
			return t;
		}
	}

	/**
	 * La methode isReset permet de verifier si un arc est vide
	 */
	@Override
	public boolean isReset() {
		if (arcin==null) {
			 return false;
		}
		else {
			if(arcin instanceof ArcEmpty ) {
				return true;
			}else {
				return false;
			}
		}
	}

	/**
	 * La methode isRegular permet de verfier si un arc est simple
	 */
	@Override
	public boolean isRegular() {
		if (arcin==null) {
			 return true;
		}
		else {
			if(arcin instanceof ArcZero || arcin instanceof ArcEmpty ) {
				return false;
			}else {
				return true;
			}
		}
	}

	/**
	 * La methode isInhibitory permet de verfier si un arc est simple
	 */
	@Override
	public boolean isInhibitory() {
		if (arcin==null) {
			 return false;
		}
		else {
			if(arcin instanceof ArcZero ) {
				return true;
			}else {
				return false;
			}
		}
	}

	/**
	 * La methode getMultiplicity permet de retourner le poids de l'arc
	 */
	@Override
	public int getMultiplicity() throws ResetArcMultiplicityException {
		if (arcin==null) {
			return arcout.get_weight();
		}
		else {
			return arcin.get_weight();
		}
	}

	/**
	 * La methode setMultiplicity permet de changer le poids de l'arc
	 */
	@Override
	public void setMultiplicity(int multiplicity) throws ResetArcMultiplicityException {
		if (arcin==null) {
			arcout.setweight(multiplicity);
		}
		else {
			arcin.setweight(multiplicity);
		}
	}

}
