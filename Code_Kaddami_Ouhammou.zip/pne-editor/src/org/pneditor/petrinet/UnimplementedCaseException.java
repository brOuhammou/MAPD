package org.pneditor.petrinet;

@SuppressWarnings("serial")
public class UnimplementedCaseException extends Exception {

	public UnimplementedCaseException(String msg) {
        super(msg);
    }
}
